Data set:
	iTrust
Domain:
	Healthcare
Source: 
	Use cases
Target: 
	Classes

Directory structure
	all_req_filenames.txt: source artifacts file (131 artifacts)
	all_code_filenames: target artifacts file (226 artifacts)
	itrust_solution_links.txt: answer matrix file (286 links)
	req: directory that contains actual source artifacts
	code: directory that contains actual target artifacts
